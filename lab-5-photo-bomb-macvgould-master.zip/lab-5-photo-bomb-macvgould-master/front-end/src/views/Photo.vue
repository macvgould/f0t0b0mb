<template>
	<div class="image">
		<div v-if="photo" class="photoInfo">
		<img :src="photo.path" />
        <p class="photoTitle">{{photo.title}}</p>
	<p class="photoDesc">{{photo.description}}</p>
        <p class="photoName">{{photo.user.username}}</p>
      </div>
      <p class="photoDate">{{formatDate(photo.created)}}</p>
      <div v-if="this.$root.$data.user">
          <textarea v-model="comment.description" type="text"></textarea>
          <button @click="AddComment">Submit</button>
      </div>
      <div v-for="comment in comments" :key="comment">{{comment.user.username}}: {{comment.description}}     {{formatDate(comment.created)}}</div>
      </div>
</template>

<script>
import axios from 'axios';
import moment from 'moment';
export default {
	name: 'photo',
	data(){
		return{
			photoID: "",
			photo:{},
			comment: {description: ""},
			comments: [],
		}	
	},
	async created(){
	try{
		this.photoID = this.$route.params.id;
		this.photo = (await axios.get('/api/photos/photo/' + this.photoID)).data;
		await this.GetComments();
		}catch(err){
		console.log("err");
		}
	},
	methods:{
	formatDate(date) {
      if (moment(date).diff(Date.now(), 'days') < 15)
        return moment(date).fromNow();
      else
        return moment(date).format('d MMMM YYYY');
    },
    async GetComments(){
	console.log("trying to get comments");
	let response = await axios.get('/api/comments/' + this.photoID);
	this.comments = response.data;
	console.log(response);
	console.log(this.comments);
    },
    async AddComment(){
	await axios.post('/api/comments/' + this.photoID,{
		photo: this.photo,
		user: this.$root.$data.user,
		description: this.comment.description,
	});
    }
	}
};
</script>
